<?php
/*
* ---------------------------------------------------------------------------------------------->>
***************************************************************************************************
Theme Name: cordero - Puerto Madryn
Funciones y definiciones del tema del Sindicato de Empleados Municipales Madrynenses
Theme URL: 
Descripcion: Tiene todas las funciones y definiciones utilizadas en el tema cordero
Author: Fabian Paredes - 
Version: 1.0
Tags: funciones, definiciones, responsive, tema, wordpress.
***************************************************************************************************
<<-----------------------------------------------------------------------------------------------*/

/** Le dice a WordPress que ejecute cordero_setup() when the 'after_setup_theme' hook is run. */
remove_action('wp_head', 'wp_generator');

function eliminar_completamente_version()
{

	return '';
}

add_filter('the_generator', 'eliminar_completamente_version');

add_action('after_setup_theme', 'cordero_setup');

if (!function_exists('cordero_setup')) :
	/**
	 * Setea las opciones iniciales de Wordpess.
	 *
	 * @uses add_theme_support() To add support for post thumbnails, custom headers and backgrounds, and automatic feed links.
	 * @uses register_nav_menus() To add support for navigation menus.
	 * @uses add_editor_style() To style the visual editor.
	 * @uses load_theme_textdomain() For translation/localization support.
	 * @uses register_default_headers() To register the default custom header images provided with the theme.
	 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
	 *
	 * @since Twenty Ten 1.0
	 */

	function cordero_setup()
	{

		//require only in admin!
		if (is_admin()) {

			require_once('lib/cordero-theme-settings.php');
		}

		// This theme styles the visual editor with editor-style.css to match the theme style.
		add_editor_style();

		// This theme uses post thumbnails
		add_theme_support('post-thumbnails');

		// Add default posts and comments RSS feed links to head
		add_theme_support('automatic-feed-links');

		// Make theme available for translation
		// Translations can be filed in the /languages/ directory
		load_theme_textdomain('cordero', get_template_directory() . '/languages');

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(array(
			'primary' => __('Primary Navigation', 'cordero'),
		));
	}


	/**
	 * Collects our theme options
	 *
	 * @return array
	 */
	function cordero_get_global_options()
	{

		$cordero_option = array();

		// collect option names as declared in cordero_get_settings()
		$cordero_option_names = array(
			'cordero_options_general_header_tab',
			'cordero_options_general_sliderbar_tab',
			'cordero_options_general_servicios_tab',
			'cordero_options_general_slider2_tab',
			'cordero_options_general_sliderbarResponsive_tab',

		);

		// loop for get_option
		foreach ($cordero_option_names as $cordero_option_name) {

			if (get_option($cordero_option_name) != FALSE) {

				$option 	= get_option($cordero_option_name);

				// now merge in main $cordero_option array!
				$cordero_option = array_merge($cordero_option, $option);
			}
		}

		return $cordero_option;
	}

	/**
	 * Call the function and collect in variable
	 *
	 * Should be used in template files like this:
	 * <?php echo $cordero_option['cordero_txt_input']; ?>
	 *
	 * Note: Should you notice that the variable ($cordero_option) is empty when used in certain templates such as header.php, sidebar.php and footer.php
	 * you will need to call the function (copy the line below and paste it) at the top of those documents (within php tags)!
	 */
//$cordero_option = cordero_get_global_options();

endif;

/**
 * Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
 *
 * @since cordero 1.0.0
 */
function cordero_page_menu_args($args)
{

	if (!isset($args['show_home']))

		$args['show_home'] = true;

	return $args;
}

add_filter('wp_page_menu_args', 'cordero_page_menu_args');

/**
 * Utiliza un nav bar walker personalizado para cordero
 *
 * @since cordero 1.0.0
 */
class cordero_nav_walker extends walker_nav_menu
{
	private $current_item;
	private $dropdown_menu_alignment_values = [
		'dropdown-menu-start',
		'dropdown-menu-end',
		'dropdown-menu-sm-start',
		'dropdown-menu-sm-end',
		'dropdown-menu-md-start',
		'dropdown-menu-md-end',
		'dropdown-menu-lg-start',
		'dropdown-menu-lg-end',
		'dropdown-menu-xl-start',
		'dropdown-menu-xl-end',
		'dropdown-menu-xxl-start',
		'dropdown-menu-xxl-end'
	];

	function start_lvl(&$output, $depth = 0, $args = null)
	{
		$dropdown_menu_class[] = '';
		foreach ($this->current_item->classes as $class) {
			if (in_array($class, $this->dropdown_menu_alignment_values)) {
				$dropdown_menu_class[] = $class;
			}
		}
		$indent = str_repeat("\t", $depth);
		$submenu = ($depth > 0) ? ' sub-menu' : '';
		$output .= "\n$indent<ul class=\"dropdown-menu$submenu " . esc_attr(implode(" ", $dropdown_menu_class)) . " depth_$depth\">\n";
	}

	function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
	{
		$this->current_item = $item;

		$indent = ($depth) ? str_repeat("\t", $depth) : '';

		$li_attributes = '';
		$class_names = $value = '';

		$classes = empty($item->classes) ? array() : (array) $item->classes;

		$classes[] = ($args->walker->has_children) ? 'dropdown' : '';
		$classes[] = 'nav-item';
		$classes[] = 'nav-item-' . $item->ID;
		if ($depth && $args->walker->has_children) {
			$classes[] = 'dropdown-menu dropdown-menu-end';
		}

		$class_names =  join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
		$class_names = ' class="' . esc_attr($class_names) . '"';

		$id = apply_filters('nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args);
		$id = strlen($id) ? ' id="' . esc_attr($id) . '"' : '';

		$output .= $indent . '<li ' . $id . $value . $class_names . $li_attributes . '>';

		$attributes = !empty($item->attr_title) ? ' title="' . esc_attr($item->attr_title) . '"' : '';
		$attributes .= !empty($item->target) ? ' target="' . esc_attr($item->target) . '"' : '';
		$attributes .= !empty($item->xfn) ? ' rel="' . esc_attr($item->xfn) . '"' : '';
		$attributes .= !empty($item->url) ? ' href="' . esc_attr($item->url) . '"' : '';

		$active_class = ($item->current || $item->current_item_ancestor || in_array("current_page_parent", $item->classes, true) || in_array("current-post-ancestor", $item->classes, true)) ? 'active' : '';
		$nav_link_class = ($depth > 0) ? 'dropdown-item ' : 'nav-link ';
		$attributes .= ($args->walker->has_children) ? ' class="' . $nav_link_class . $active_class . ' dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"' : ' class="' . $nav_link_class . $active_class . '"';

		$item_output = $args->before;
		$item_output .= '<a' . $attributes . '>';
		$item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
		$item_output .= '</a>';
		$item_output .= $args->after;

		$output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
	}
}

/**
 * Para poner un paginador con numeros de pagina, pagina siguiente y pagina anterior
 *
 * @since cordero 1.0.0
 */
function cordero_numeric_posts_nav()
{

	if (is_singular())

		return;

	global $wp_query;

	/** Stop execution if there's only 1 page */
	if ($wp_query->max_num_pages <= 1)

		return;

	$paged = get_query_var('paged') ? absint(get_query_var('paged')) : 1;
	$max   = intval($wp_query->max_num_pages);

	/**	Add current page to the array */
	if ($paged >= 1)

		$links[] = $paged;

	/**	Add the pages around the current page to the array */
	if ($paged >= 3) {

		$links[] = $paged - 1;
		$links[] = $paged - 2;
	}
	if (($paged + 2) <= $max) {

		$links[] = $paged + 2;
		$links[] = $paged + 1;
	}

	echo '<div class="navigation  "><ul>' . "\n";

	/**	Previous Post Link */
	if (get_previous_posts_link())

		printf('<li>%s</li>' . "\n", get_previous_posts_link("<<<"));

	/**	Link to first page, plus ellipses if necessary */
	if (!in_array(1, $links)) {

		$class = 1 == $paged ? ' class="active"' : '';
		printf('<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link(1)), '1');

		if (!in_array(2, $links))

			echo '<li>…</li>';
	}

	/**	Link to current page, plus 2 pages in either direction if necessary */
	sort($links);

	foreach ((array) $links as $link) {

		$class = $paged == $link ? ' class="active"' : '';
		printf('<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($link)), $link);
	}

	/**	Link to last page, plus ellipses if necessary */
	if (!in_array($max, $links)) {

		if (!in_array($max - 1, $links))
			echo '<li>…</li>' . "\n";
		$class = $paged == $max ? ' class="active"' : '';
		printf('<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url(get_pagenum_link($max)), $max);
	}

	/**	Next Post Link */
	if (get_next_posts_link())

		printf('<li>%s</li>' . "\n", get_next_posts_link(">>>"));

	echo '</ul></div>' . "\n";
}

//cambio del logo de la pagina login de wordpress
function my_custom_login_logo()
{

	echo '<style type="text/css">

	.login {
		background-image:url(' . get_stylesheet_directory_uri() . '/images/logo1-redondeado.png) !important;
		background-repeat: no-repeat;
		background-position-y: 50%;
		background-position-x: 50%;
		background-size: 50%;
	}
	.login label{
		color: #FFF;
	}
	.login form{
		background: rgba(0, 0, 0, 0.7) !important;

	}
	h1 a {
		background-image:url(' . get_stylesheet_directory_uri() . '/images/cordero_logo.png) !important;
		background-size: 80px 82px !important;
		height: 82px !important;
		padding-bottom: 0 !important;
		width: 100% !important
	}

	.login #backtoblog a, .login #nav a {
		text-decoration: none;
		color: #FFF;
	}
	</style>';
}

add_action('login_head', 'my_custom_login_logo');


// cambio el texto emergente de la URL de página de login
function put_my_title()
{

	return ('Desarrollado por Panteon Software'); // cambio el texto "Powered by WordPress" por el que quiera

}

add_filter('login_headertitle', 'put_my_title');

//Filter de logueo, muestra un mensaje solo de error
// add_filter('login_errors', create_function('$a', "return 'ERROR!';"));


//Cambia el color de el panel de fondo de la administración
function cordero_admin_dashboard_color()
{

	if (is_admin()) {

		echo '<style>

		#adminmenu .wp-menu-image img{
			padding: 10px;
			width: 70%;
		}

		#theme-header{
			background: #3b70b1;
			margin: -20px 0px 0px -23px;
			border-bottom: 3px solid #3BBA91;
		}

		 .theme-box{
			 background: #dce0e5;
			  }
				.theme-box .theme-box-content{
				 		background: #dce0e5;
				 	}

				</style>';
	}
}

add_action('admin_head', 'cordero_admin_dashboard_color');
/********************************************************************************/

add_action('media_buttons', 'add_my_media_button');

function add_my_media_button()
{

	echo '<a href="#" id="insert-my-media" class="button">Add my media</a>';
}

// boton agregar archivo
function include_media_button_js_file()
{

	wp_enqueue_script('media_button', 'path/to/media_button.js', array('jquery'), '1.0', true);
}

add_action('wp_enqueue_media', 'include_media_button_js_file');


// define query vars para la busqueda de entradas
function add_custom_query_var($vars)
{

	$vars[] = "d";
	return $vars;
}

add_filter('query_vars', 'add_custom_query_var');

/* Reglas de reescritura de color para tipos de publicaciones personalizadas. */
add_action('after_switch_theme', 'bt_flush_rewrite_rules');

/* Vacíe sus reglas de reescritura */
function bt_flush_rewrite_rules()
{

	flush_rewrite_rules();
}

/*Agregado de scripts y styles */
add_action("wp_enqueue_scripts", "incrustar_estilos");

function incrustar_estilos()
{
	/*CSS*/
	wp_register_style('bootstrapCSS', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css', false, NULL);
	wp_register_style('styleCSS', get_template_directory_uri() . '/css/style.css?v=' . time(), false, null);
	wp_register_style('FontGoogleCSS', 'https://fonts.googleapis.com/css?family=Comfortaa|Raleway|Fjalla+One', false, NULL);
	wp_register_style('fontAwesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css', true);

	/*JS*/
	wp_register_script('bootstrapJS', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js', false);
	// wp_register_script('mainJS', get_template_directory_uri() . '/js/main.js', array('jquery'), '1', false);
	wp_register_script('popperJS', 'https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js', false);
	wp_register_script('jqueryUI', 'https://code.jquery.com/jquery-3.2.1.slim.min.js', array('jquery'), '1', false);
	wp_register_script('googleJS', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDrBONhVuRlIoJc51SofDX7OVSYYCmfoYg', array('jquery'), '1', false);


	// nos aseguramos que no estamos en el area de administracion
	if (!is_admin()) {

		wp_enqueue_style('styleCSS');
		wp_enqueue_style('FontGoogleCSS');
		wp_enqueue_style('bootstrapCSS');
		wp_enqueue_style('fontAwesome');

		wp_enqueue_script('bootstrapJS');
		wp_enqueue_script('popperJS');
		wp_enqueue_script('jqueryUI');
		wp_enqueue_script('googleJS');

		
	}
	
}


add_action('admin_menu', 'remover_menus');

function remover_menus()
{

	//Eliminar menu de comentarios
	remove_menu_page('edit-comments.php');
}
