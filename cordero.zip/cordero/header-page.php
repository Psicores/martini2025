<?php

/**
 * Theme Name: Header Pagina del tema de  Fiesta del Cordero
 * Theme URI:
 * Author: Municipalidad de Puerto Madryn
 * Author URI: 
 * Description: Cabecera con menu del sitio
 * Version: 1.0
 */
?>
<?php $template_option = cordero_get_global_options(); ?>

<!DOCTYPE html>
<html lang="<?php bloginfo('language') ?>">

<head>
    <meta charset="<?php bloginfo('charset') ?>">
    <meta name="description" content="<?php bloginfo('description') ?>">
    <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/manifest.json">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php bloginfo(); ?></title>
    <?php wp_head(); ?>
</head>

<body>

    <header class="header-section position-relative top-0 start-0" style="z-index:100;">
        <!-- <nav id="cordero-nav" class="navbar navbar-expand-lg navbar-light bg-light" -->
        <nav id="cordero-nav"
            class="navbar navbar-expand-lg navbar-light bg-light p-0 bg-transparent position-absolute mt-5 w-100"
            style="font-family: gotham2; color: white; font-size: 1.5em;" role="navigation">

            <div class="container-fluid">

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarmenu"
                    aria-controls="navbarmenu" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                    </span>
                </button>

                <div class="collapse navbar-collapse" id="navbarmenu">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'menu_nav border-white manejo-fuente nav navbar-nav ml-auto w-100 justify-content-center col',
                        'fallback_cb' => '__return_false',
                        'items_wrap' => '<ul id="%1$s" class="navbar-nav mx-auto mb-2 mb-md-0 %2$s">%3$s</ul>',
                        'depth' => 2,
                        'walker' => new cordero_nav_walker(),
                    ));
                    ?>
                </div>
            </div>
        </nav>
    </header>

    <div class="">



    </div>