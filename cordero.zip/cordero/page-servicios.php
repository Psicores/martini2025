<?php
/*
* ---------------------------------------------------------------------------------------------->>
***************************************************************************************************
Template Name: pagina-servicios
Theme Name: cordero - Puerto Madryn
Theme URL: http://cordero.com.ar
Descripcion: Cuerpo principal de los servicios
Author: 
Version: 1.1
***************************************************************************************************
<<-----------------------------------------------------------------------------------------------*/
?>

<?php get_header('servicios'); ?>

<section>

    <?php    //Obtener la imagen de la noticia destino
    if (has_post_thumbnail(get_the_ID())) { //Si tiene una imagen destacada mostrarla
    ?>
        <div class="img-pagina-gral">
            <?php
            echo get_the_post_thumbnail(get_the_ID(), 'full', array('class' => 'cont-pag-thumb')); //Opciones: medium, large, full
            ?>
        </div>
    <?php   } ?>


    <?php if (have_posts()) : while (have_posts()) : the_post();  ?>
            <div class="col-12 text-center mt-5 mb-3">
                <h2><?php the_title(); ?></h2>
            </div>

            <div class="col-12 manejo-serv justify-content-start">
                <?php the_content(); ?>
            </div>

        <?php endwhile; ?>
    <?php endif; ?>

</section>

<?php get_footer(); ?>