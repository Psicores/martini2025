<?php

/**
 * Pagina principal del tema de  Fiesta del Cordero
 * Theme URL:
 * Descripcion: Página de inicio del tema Fiesta del Cordero
 * Author: Municipalidad de Puerto Madryn - Desarrollo Web
 * Version: 1.0
 * Tags: funciones, definiciones, responsive, tema, wordpress.
 */
?>
<?php get_header(); ?>
<?php $template_option = cordero_get_global_options(); ?>
<?php
$redes_face =  $template_option['cordero_facebook'];
$redes_twitter = $template_option['cordero_twitter'];
$redes_insta = $template_option['cordero_instagram'];
$redes_youtube = $template_option['cordero_youtube'];
$programa = $template_option['cordero_programa'];
$redes_entradas = $template_option['cordero_entradas'];

$url_artistas =  $template_option['cordero_url_artistas'];
$titulo_artistas =  $template_option['cordero_titulo_artistas'];

$url_gastronomicos =  $template_option['cordero_url_gastronomicos'];
$titulo_gastronomicos =  $template_option['cordero_titulo_gastronomicos'];

$url_artesanos =  $template_option['cordero_url_artesanos'];
$titulo_artesanos =  $template_option['cordero_titulo_artesanos'];

$url_comerciales =  $template_option['cordero_url_comerciales'];
$titulo_comerciales =  $template_option['cordero_titulo_comerciales'];

$leyenda1 =  $template_option['cordero_leyenda1'];
$leyenda2 =  $template_option['cordero_leyenda2'];



?>
<div id="carouselCorderoIndicator" class="carousel slide slider d-none d-sm-block" data-bs-ride="true">

    <div class="carousel-inner">
        <?php
        $control = true;
        $slider_exist = 0;
        for ($i = 1; $i <= 3; $i++) {
            if (!empty($template_option['cordero_slider_img' . $i]) || '' != $template_option['cordero_slider_img' . $i]) { ?>

                <div class="carousel-item <?php echo ($control) ? 'active' : '' ?>">
                    <?php
                    $control = false;
                    $slider_exist++; ?>

                    <a href="<?php echo $template_option['cordero_slider_url' . $i]; ?> " target="_blank">
                        <img class="d-block w-100 img-fluid img-carousel-back" src="<?php echo $template_option['cordero_slider_img' . $i]; ?>">
                    </a>

                </div>
        <?php }
        }
        ?>
    </div>
    <?php if ($slider_exist > 1) { ?>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselCorderoIndicator" data-bs-slide="prev">
            <img src="<?php bloginfo('template_directory') ?>/images/sliderIconIzquierdo.svg" alt="" class="text-center zoom manejo-icono-slider"> </button>

        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselCorderoIndicator" data-bs-slide="next">
            <img src="<?php bloginfo('template_directory') ?>/images/sliderIconDerecho.svg" alt="" class="text-center zoom manejo-icono-slider"> </button>

        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
        </button>
    <?php } ?>
</div>



<!------------------------------------ Slider Celular -------------------------------------------->
<!--  -->
<div class="d-block d-sm-none" style="max-height: 1000px; overflow: hidden;" data-bs-ride="true">
    <div class="manejo-cabecera">
        <a href="<?php echo $template_option['cordero_url']; ?> " target="_blank">
            <img class="d-block w-100 img-fluid img-carousel-back" src="<?php bloginfo('template_directory') ?>/images/celular-banner.jpg">
        </a>
    </div>
</div>



<div class="manejo-redes text-center ">
    <?php if (!empty($redes_face)) { ?>
        <a class="navbar-brand" href="<?php echo $redes_face  ?>" target="_blank" rel=" noopener noreferrer">
            <img src="<?php bloginfo('template_directory') ?>/images/facebookWeb.svg" alt=""> </button>
        </a>
    <?php } ?>

    <?php if (!empty($redes_twitter)) { ?>
        <a class="navbar-brand" href="<?php echo $redes_twitter  ?>" target="_blank" rel=" noopener noreferrer">
            <img src="<?php bloginfo('template_directory') ?>/images/twiterWeb.svg" alt="" class="text-center zoom manejo-icono-redes"> </button>
        </a>
    <?php } ?>

    <?php if (!empty($redes_insta)) { ?>
        <a class="navbar-brand" href="<?php echo $redes_insta  ?>" target="_blank" rel=" noopener noreferrer">
            <img src="<?php bloginfo('template_directory') ?>/images/instagramWeb.svg" alt="" class="text-center zoom manejo-icono-redes"> </button>
        </a>
    <?php } ?>
</div>
<div class="container leyendas ">
    <p class=" text-center manejo-fuente-leyendas">
        <?php echo $leyenda1 ?>
    </p>
</div>
<!-- *********************************************** SERVICIOS *************************************************** -->
<section>
    <div class="container mb-5 mt-5">
        <div class="row manejo-servicios">
            <article class="col-sm-12 col-md-6 text-center zoom">
                <h1 class="manejo-titulo-insc mb-3">INSCRIPCIÓN</h3>
                    <a href="<?php echo $url_artistas  ?>" class="text-decoration-none">
                        <img src="<?php bloginfo('template_directory') ?>/images/artistas.svg" alt="" class="text-center zoom">
                        <div class="manejo-titulo">
                            <p class="mb-0 mt-4">
                                <?php echo $titulo_artistas ?>
                        </div>
                    </a>
            </article>
            <article class="col-sm-12 col-md-6 text-center zoom">
                <h1 class="manejo-titulo-insc mb-3">INSCRIPCIÓN</h3>
                    <a href="<?php echo $url_gastronomicos  ?>" class="text-decoration-none">
                        <img src="<?php bloginfo('template_directory') ?>/images/gastronomicos.svg" alt="" class="text-center zoom">
                        <div class="manejo-titulo">
                            <p class="mb-0 mt-4">
                                <?php echo $titulo_gastronomicos ?>
                        </div>
                    </a>
            </article>
            <!--  <article class="col-sm-12 col-md-3 text-center zoom">
                <a href="<?php echo $url_artesanos  ?>" class="text-decoration-none">
                    <img src="<?php bloginfo('template_directory') ?>/images/artesanos.svg" alt="" class="text-center zoom">
                    <div class="manejo-titulo">
                        <p class="mb-0 mt-4 ">
                            <?php echo $titulo_artesanos ?>
                    </div>
                </a>
            </article>
            <article class="col-sm-12 col-md-3 text-center zoom">
                <a href="<?php echo $url_comerciales  ?>" class="text-decoration-none">
                    <img src="<?php bloginfo('template_directory') ?>/images/comerciales.svg" alt="" class="text-center zoom">
                    <div class="manejo-titulo">
                        <p class="mb-0 mt-4">
                            <?php echo $titulo_comerciales ?>
                    </div>
                </a>
            </article>-->
        </div>
    </div>
</section>
<!-- *********************************************** SERVICIOS *************************************************** -->
<!-- ************************************************ SLIDERS 2 ****************************************************-->
<div id="centroCorderoIdicator" class="carousel slide slider d-none d-sm-block" data-bs-interval="2000" data-bs-ride="carousel">

    <div class="carousel-inner">
        <?php
        $control = true;
        $slider_exist = 0;
        for ($i = 1; $i <= 4; $i++) {
            if (!empty($template_option['cordero_slider2_img' . $i])) { ?>

                <div class="carousel-item <?php echo ($control) ? 'active' : '' ?>">
                    <?php
                    $control = false;
                    $slider_exist++; ?>
                    <a href="<?php echo $template_option['cordero_slider2_url' . $i]; ?>" target="_blank">
                        <img class="d-block w-100 img-fluid img-carousel-back" src="<?php echo $template_option['cordero_slider2_img' . $i]; ?>">
                    </a>
                </div>
        <?php }
        }
        ?>
    </div>
    <?php if ($slider_exist > 1) { ?>
        <button class="carousel-control-prev" type="button" data-bs-target="#centroCorderoIdicator" data-bs-slide="prev">
            <img src="<?php bloginfo('template_directory') ?>/images/sliderIconIzquierdo.svg" alt="" class="text-center zoom manejo-icono-slider"> </button>
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>

        <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#centroCorderoIdicator" data-bs-slide="next">
            <img src="<?php bloginfo('template_directory') ?>/images/sliderIconDerecho.svg" alt="" class="text-center zoom manejo-icono-slider"> </button>

        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
        </button>
    <?php } ?>
</div>

<!----------------------------------------- SLIDER 2 CELULAR-------------------------------------- -->
<div id="carouselCorderoIndicatorCelu" class="carousel slide slider d-block d-sm-none" data-bs-interval="2000" data-bs-ride="carousel" style="max-height: 1000px; overflow: hidden;">
    <div class="carousel-inner">
        <?php
        $control = true;
        $slider_exist = 0;
        for ($i = 1; $i <= 4; $i++) {
            if (!empty($template_option['cordero_sliderCelular_img' . $i]) || '' != $template_option['cordero_sliderCelular_img' . $i]) { ?>

                <div class="carousel-item <?php echo ($control) ? 'active' : '' ?>">
                    <?php
                    $control = false;
                    $slider_exist++; ?>

                    <a href="<?php echo $template_option['cordero_sliderCelular_url' . $i]; ?> " target="_blank">
                        <img class="d-block w-100 img-fluid img-carousel-back" src="<?php echo $template_option['cordero_sliderCelular_img' . $i]; ?>">
                    </a>
                </div>
        <?php }
        }
        ?>
    </div>
    <?php if ($slider_exist > 1) { ?>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselCorderoIndicatorCelu" data-bs-slide="prev">
            <span class="visually-hidden">Previous</span>
            <img src="<?php bloginfo('template_directory') ?>/images/sliderIconIzquierdo.svg" alt="" class="text-center zoom manejo-icono-slider"> </button>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselCorderoIndicatorCelu" data-bs-slide="next">
            <span class="visually-hidden">Next</span>
            <img src="<?php bloginfo('template_directory') ?>/images/sliderIconDerecho.svg" alt="" class="text-center zoom manejo-icono-slider"> </button>
        </button>
    <?php } ?>
</div>

<div class="container leyendas d-none d-sm-block">
    <p class="text-center manejo-fuente-leyendas mt-5">
        <?php echo $leyenda2 ?>
    </p>
</div>

<!-- ************************************************ SLIDERS 2 ****************************************************-->


<!-- ************************************************** ENTRADAS Y PROGRAMAS ************************************** -->

<section>
    <div class="container">
        <div class="col-sm-12 servicios">
            <div class="row my-5">
                <article id="entradas" class="col-sm-12 col-md-6 text-center">
                    <a href="https://fiestadelcordero.madryn.gob.ar/entradas/" class="text-decoration-none">
                        <p class="manejo-fuente-servicios">ENTRADAS</p>
                        <img src="<?php bloginfo('template_directory') ?>/images/entradas.svg" width="auto" height="150px" alt="" class="text-center mb-5">
                    </a>
                </article>
                <article id="programa" class="col-sm-12 col-md-6 m text-center">
                    <a href="https://fiestadelcordero.madryn.gob.ar/programa/" class="text-decoration-none">
                        <p class="manejo-fuente-servicios">PROGRAMA</p>
                        <img src="<?php bloginfo('template_directory') ?>/images/descargar.svg" width="auto" height="150px" alt="" class="text-center mb-5">
                    </a>
                </article>
            </div>
        </div>
    </div>

</section>


<!-- ************************************************** ENTRADAS Y PROGRAMAS ************************************** -->


<!-- ************************************************** INICIO NOTICIAS **********************************************-->
<section>
    <div class="container noticias">

        <div class="row manejo-noticia">

            <?php
            // Ignora los post de la categoria quedate en casa
            query_posts(array('post_type' => 'post', 'ignore_sticky_posts' =>
            true, 'posts_per_page' => 4, 'cat' => array(-219, -221, -222, -230, -232, -238, -240), 'paged' => get_query_var('paged')));
            $counte_post = 0;

            if (have_posts()) : while (have_posts()) : the_post();
            ?>
                    <div class="row col-md-6 mb-4 ps-5 pe-4">
                        <div class="card border border-3 manejo-card col mb-3">
                            <div class="card-body text-center">
                                <h3 class="card-title fw-bold justify manejo-fuente-noticias">
                                    <?php the_title(); ?></h3>
                            </div>
                            <div class="noticia-img">
                                <?php
                                echo get_the_post_thumbnail(get_the_ID(), 'medium_large', array('class' => 'cont-pag-thumb')); //Opciones: medium, large, full
                                ?>
                            </div>


                            <div class="mb-3 mt-3 text-center ">
                                <a href="<?php the_permalink(); ?> " class="fw-bold manejo-ver text-decoration-none" rel="bookmark">
                                    VER NOTA COMPLETA
                                </a>
                            </div>

                        </div>
                    </div>

                <?php endwhile; ?>
            <?php endif; ?>

        </div>
        <div class="row">
            <div class="col text-center">
                <a href="https://fiestadelcordero.madryn.gob.ar/ultimas-noticias/ ?>" class="fw-bold manejo-ver-mas text-decoration-none" rel="bookmark">
                    <button class="btn btn-secondary text-center"> MÁS NOTICIAS</button>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- *********************************************** FIN NOTICIAS *****************************************************-->

<!-- *********************************************** MAPA RESPONSIVO ************************************************** -->

<div class="map-responsive manejo-mapa">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2929.9641372193864!2d-65.04383108496893!3d-42.74681097916279!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xbe024be7816257ef%3A0x99faa8bfcbcede78!2sClub%20Social%20y%20Deportivo%20Madryn!5e0!3m2!1ses-419!2sar!4v1660738757283!5m2!1ses-419!2sar"></iframe>
</div>
<!-- width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" -->

<!-- *********************************************** MAPA RESPONSIVO ************************************************** -->
<!-- </div> -->
<?php get_footer(); ?>