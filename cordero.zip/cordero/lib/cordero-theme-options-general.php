<?php

/**
 * Definimos los tabs de las opciones
 * Cada uno de los titulos ($title) es el titulo de la pestaña del tab
 *
 * array key=$id, array value=$title in: add_settings_section( $id, $title, $callback, $page );
 * @return array
 */
function cordero_general_options_page_tabs()
{

	$tabs = array();
	//$tabs[$id] 			= __($title, 'cordero_textdomain');
	$tabs['header-tab'] 	= __('Redes Sociales', 'cordero_tabs');
	$tabs['sliderbar-tab'] 	= __('Banners Cabecera WEB', 'cordero_tabs');
	$tabs['sliderbarResponsive-tab'] 	= __('Banners Centro Celular', 'cordero_tabs');
	// $tabs['sliderbarResponsiveCabecera-tab'] 	= __('Banners Cabecera Celular', 'cordero_tabs');
	$tabs['slider2-tab'] 	= __('Banners Centro WEB', 'cordero_tabs');
	$tabs['servicios-tab'] 	= __('Servicios', 'cordero_tabs');
	return $tabs;
}

/**
 * Definimos las secciones de cada uno de los tabs
 * Cada uno de los titulos ($title) es el titulo que aparece en el encabezado de las opciones de
 * esa seccion.
 *
 * array key=$id, array value=$title in: add_settings_section( $id, $title, $callback, $page );
 * @return array
 */
function cordero_general_options_page_sections()
{
	// we change the output based on open tab

	// get the current tab
	$tab = cordero_get_the_tab();

	// switch sections array according to tab
	switch ($tab) {

		case 'header-tab':
			$sections = array();
			$sections['header_section'] 		= __('_______________ REDES SOCIALES _______________', 'cordero_textdomain');
			break;

		case 'sliderbar-tab':
			$sections = array();
			$sections['sliderbar_section'] 		= __('_______________ BANNERS CABECERA _______________', 'cordero_textdomain');
			break;

		case 'sliderbarResponsive-tab':
			$sections = array();
			$sections['sliderbarResponsive_section'] 		= __('_______________ BANNERS CENTRO CELULAR _______________', 'cordero_textdomain');
			break;

		case 'sliderbarResponsiveCabecera-tab':
			$sections = array();
			$sections['sliderbarResponsiveCabecera_section'] 		= __('_______________ BANNERS CABECERA CELULAR _______________', 'cordero_textdomain');
			break;

		case 'slider2-tab':
			$sections = array();
			$sections['slider2_section'] 		= __('_______________ BANNERS CENTRO _______________', 'cordero_textdomain');
			break;


		case 'servicios-tab':
			$sections = array();
			$sections['servicios_section'] 		= __('_______________ SERVICIOS _______________', 'cordero_textdomain');
			break;

	
	}

	return $sections;
}


/**
 * Definimos los campos de las opciones
 *
 * @return array
 */
function cordero_general_options_page_fields()
{
	// get the current tab
	$tab = cordero_get_the_tab();

	$años_array = array();


	for ($i = 2017; $i < 2040; $i++) {

		$años_array[] = $i;
	}

	// setting fields according to tab
	switch ($tab) {
			//********************************* PESTAÑA DE PAGINA DE INICIO *********************************\\
		case 'header-tab':
			//URL relativa a la imagen estatica
			//Facebook

			$options[] = array(
				"section" => "header_section",
				"id"      => PRE_SHORTNAME . "_facebook",
				"title"   => __('Facebook', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de facebook.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);

			//Twitter
			$options[] = array(
				"section" => "header_section",
				"id"      => PRE_SHORTNAME . "_twitter",
				"title"   => __('Twitter', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de twitter.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);

			//Youtube
			$options[] = array(
				"section" => "header_section",
				"id"      => PRE_SHORTNAME . "_youtube",
				"title"   => __('Youtube', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de youtube.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);

			//Instagram
			$options[] = array(
				"section" => "header_section",
				"id"      => PRE_SHORTNAME . "_instagram",
				"title"   => __('Instagram', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de instagram.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);
			//Instagram
			$options[] = array(
				"section" => "header_section",
				"id"      => PRE_SHORTNAME . "_entradas",
				"title"   => __('Entradas', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);


			break;
			// Dentro de el for va la cantidad de tabs que quieran poner 
		case 'sliderbar-tab':

			for ($i = 1; $i <= 4; $i++) {

				$options[] = array(
					"section" => "sliderbar_section",
					"id"      => PRE_SHORTNAME . "_slider_img" . $i,
					"title"   => __('Imagen ' . $i, 'cordero_textdomain'),
					"desc"    => __($i, 'cordero_textdomain'),
					"type"    => "image",
					"std"     => __('', 'cordero_textdomain'),
					"class"   => "nohtml"
				);
				// //URL relativa a la noticia de la imagen
				$options[] = array(
					"section" => "sliderbar_section",
					"id"      => PRE_SHORTNAME . "_slider_url" . $i,
					"title"   => __('URL ' . $i, 'cordero_textdomain'),
					"desc"    => __('Ingrese la dirección URL asociada a la imagen' . $i, 'cordero_textdomain'),
					"type"    => "text",
					"std"     => "",
					"class"   => "url"
				);
			}
			break;


		case 'sliderbarResponsive-tab':

			for ($i = 1; $i <= 4; $i++) {

				$options[] = array(
					"section" => "sliderbarResponsive_section",
					"id"      => PRE_SHORTNAME . "_sliderCelular_img" . $i,
					"title"   => __('Imagen ' . $i . ' Celular - 360 x 740  ', 'cordero_textdomain'),
					"desc"    => __($i, 'cordero_textdomain'),
					"type"    => "image",
					"std"     => __('', 'cordero_textdomain'),
					"class"   => "nohtml"
				);
				// //URL relativa a la noticia de la imagen
				$options[] = array(
					"section" => "sliderbarResponsive_section",
					"id"      => PRE_SHORTNAME . "_sliderCelular_url" . $i,
					"title"   => __('URL ' . $i, 'cordero_textdomain'),
					"desc"    => __('Ingrese la dirección URL asociada a la imagen' . $i, 'cordero_textdomain'),
					"type"    => "text",
					"std"     => "",
					"class"   => "url"
				);
			}
			break;
		case 'sliderbarResponsiveCabecera-tab':
			$options[] = array(
				"section" => "sliderbarResponsiveCabecera_section",
				"id"      => PRE_SHORTNAME . "_img",
				"title"   => __('Imagen' , 'cordero_textdomain'),
				"desc"    => __('Imagen', 'cordero_textdomain'),
				"type"    => "image",
				"std"     => __('', 'cordero_textdomain'),
				"class"   => "nohtml"
			);	

			$options[] = array(
				"section" => "sliderbarResponsiveCabecera_section",
				"id"      => PRE_SHORTNAME . "_url",
				"title"   => __('URL', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);

			break;

		case 'slider2-tab':
			for ($i = 1; $i <= 5; $i++) {

				$options[] = array(
					"section" => "slider2_section",
					"id"      => PRE_SHORTNAME . "_slider2_img" . $i,
					"title"   => __('1857px X 574px  Imagen ' . $i, 'cordero_textdomain'),
					"desc"    => __('Tamaño ideal de la imagen: 2560px X 791px slider2' . $i, 'cordero_textdomain'),
					"type"    => "image",
					"std"     => __('', 'cordero_textdomain'),
					"class"   => "nohtml"
				);
				//URL relativa a la noticia de la imagen
				$options[] = array(
					"section" => "slider2_section",
					"id"      => PRE_SHORTNAME . "_slider2_url" . $i,
					"title"   => __('URL ' . $i, 'cordero_textdomain'),
					"desc"    => __('Ingrese la dirección URL asociada a la imagen' . $i, 'cordero_textdomain'),
					"type"    => "text",
					"std"     => "",
					"class"   => "url"
				);
			}
			break;




		case 'servicios-tab':
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_titulo_artistas",
				"title"   => __('Título Artista', 'cordero_textdomain'),
				"desc"    => __('Título ', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => __('', 'cordero_textdomain'),
				"class"   => "nohtml"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_url_artistas",
				"title"   => __('Artistas URL', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de artistas.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_titulo_gastronomicos",
				"title"   => __('Título Gastronomicos ', 'cordero_textdomain'),
				"desc"    => __('Título ', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => __('', 'cordero_textdomain'),
				"class"   => "nohtml"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_url_gastronomicos",
				"title"   => __('Gastronómicos URL', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de gastronómicos.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_titulo_artesanos",
				"title"   => __('Título Artesanos', 'cordero_textdomain'),
				"desc"    => __('Título ', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => __('', 'cordero_textdomain'),
				"class"   => "nohtml"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_url_artesanos",
				"title"   => __('Artesanos URL', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de artesanos.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_titulo_comerciales",
				"title"   => __('Título Comerciales', 'cordero_textdomain'),
				"desc"    => __('Título ', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => __('', 'cordero_textdomain'),
				"class"   => "nohtml"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_url_comerciales",
				"title"   => __('Comerciales URL', 'cordero_textdomain'),
				"desc"    => __('Ingrese la dirección URL de la página de comerciales.', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => "",
				"class"   => "url"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_leyenda1",
				"title"   => __('Leyenda 1', 'cordero_textdomain'),
				"desc"    => __('Leyenda 1', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => __('', 'cordero_textdomain'),
				"class"   => "nohtml"
			);
			$options[] = array(
				"section" => "servicios_section",
				"id"      => PRE_SHORTNAME . "_leyenda2",
				"title"   => __('Leyenda 2', 'cordero_textdomain'),
				"desc"    => __('Leyenda ', 'cordero_textdomain'),
				"type"    => "text",
				"std"     => __('', 'cordero_textdomain'),
				"class"   => "nohtml"
			);
			break;
			// case 'servicios2-tab':
			// 	$options[] = array(
			// 		"section" => "servicios2_section",
			// 		"id"      => PRE_SHORTNAME . "_leyenda",
			// 		"title"   => __('Leyenda', 'cordero_textdomain'),
			// 		"desc"    => __('Leyenda ', 'cordero_textdomain'),
			// 		"type"    => "text",
			// 		"std"     => __('', 'cordero_textdomain'),
			// 		"class"   => "nohtml"
			// 	);
			// 	break;

	}
	return $options;
}
function cordero_general_options_page_contextual_help()
{

	// get the current tab
	$tab = cordero_get_the_tab();

	$text 	= "<h3>" . __('Opciones MuniV2 - Ayuda Contextual', 'muniv2_textdomain') . "</h3>";

	// contextual help according to tab
	switch ($tab) {
			// Cabecera
		case 'header-tab':
			$text 	.= "<p>" . __('Ayuda contextual para los campos de las opciones del Encabezado van acá.', 'muniv2_textdomain') . "</p>";
			break;
	}

	// return text
	return $text;
}
