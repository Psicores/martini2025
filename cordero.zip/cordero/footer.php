<!-- Footer -->
<footer id="contacto" class="page-footer">

  <!-- Footer Links -->
  <div class="container-fluid">

    <!-- Grid row -->
    <div class="row manejo-row">
      <!-- Comentario -->
      <div class="col-md-6 col-lg-3 manejo-logo">
        <div class="col-12 text-center cordero">
          <img class="img-fluid" src="<?php bloginfo('template_directory') ?>/images/C2.svg">
        </div>
      </div>
      <div class="col-md-6 col-lg-3 manejo-logo">
        <div class="col-12 text-center veinti">
          <img class="img-fluid" src="<?php bloginfo('template_directory') ?>/images/25A.svg">
        </div>
      </div>
      <div class="col-md-6 col-lg-3 manejo-logo">
        <div class="col-12 text-center deportivo">
          <img class="img-fluid" src="<?php bloginfo('template_directory') ?>/images/contacto.svg">
        </div>
      </div>

      <div class="col-md-6 col-lg-3 manejo-logo">
        <div class="col-12 text-center madryn">
          <img class="img-fluid" src="<?php bloginfo('template_directory') ?>/images/madryn.svg">
        </div>
      </div>
    </div>
  </div>
  </div>
</footer>
</body>

</html>