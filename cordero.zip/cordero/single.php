<?php

/**
 * Template Name: page-single
 *Theme Name: cordero - Puerto Madryn
 * Theme URI: http://madryn.gov.ar
 * Author: Fabian Paredes - Dirección de Sistemas y Seguridad Informática - Municipalidad de Puerto Madryn
 * Author URI: http://madryn.gov.ar/
 * Description: Pagina para mostrar post
 * Version: 2.0
 */
?>
<?php get_header('single'); ?>

<section>
    <div class="container-fluid mb-3 p-3">
        <?php if (have_posts()) : while (have_posts()) : the_post();  ?>
                <div class="col-12 manejo-titulo">
                    <p><?php the_title(); ?></p>
                </div>
                
                <div class="linea"></div>

                <div class="row m-0">

                    <div class="col-12 m-0">
                        <div class="col-12 m-0">
                            <?php    //Obtener la imagen de la noticia destino
                            if (has_post_thumbnail(get_the_ID())) { //Si tiene una imagen destacada mostrarla
                            ?>
                                <div class="img-p-gral">
                                    <?php
                                    echo get_the_post_thumbnail(get_the_ID(), 'full', array('class' => 'cont-pag-thumb')); //Opciones: medium, large, full
                                    ?>
                                </div>
                            <?php   } ?>

                            <div class="col-12 m-0">
                                <div class="manejo-contenido justify-content-start">
                                    <?php the_content(); ?>
                                </div>
                            </div>

                        </div>

                    </div>

                <?php endwhile; ?>
            <?php endif; ?>

                </div>
</section>
<?php get_footer(); ?>