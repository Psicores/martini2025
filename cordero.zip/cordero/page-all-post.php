<?php
/*
* ---------------------------------------------------------------------------------------------->>
***************************************************************************************************
Template Name: page-all-post
Theme Name: cordero - Puerto Madryn
Theme URL: http://cordero.com.ar
Descripcion: 
Author: 
Version: 1.1
***************************************************************************************************
<<-----------------------------------------------------------------------------------------------*/
?>
<?php get_header('single'); ?>

<div section>
    <div class="container">

        <div class="row manejo-noticia">

            <div class="col-12 text-center mb-3  manejo-fuente"><hr/>
                <h1>TODAS LAS NOTICIAS</h1><hr/>                
            </div>

            <?php
            // Ignora los post de la categoria quedate en casa
            query_posts(array('post_type' => 'post', 'ignore_sticky_posts' =>
            true, 'posts_per_page' => 6, 'cat' => array(-219, -221, -222, -230, -232, -238, -240), 'paged' => get_query_var('paged')));
            $counte_post = 0;

            if (have_posts()) : while (have_posts()) : the_post();
            ?>
                    <div class="row col-md-4 m-0">
                        <div class="card col mb-3">
                            <div class="noticia-img">
                                <?php
                                echo get_the_post_thumbnail(get_the_ID(), 'medium', array('class' => 'cont-pag-thumb')); //Opciones: medium, large, full
                                ?>
                            </div>
                            <div class="card-body text-center">
                                <h3 class="card-title font-weight-bold justify text-dark manejo-fuente-noticias"><?php the_title(); ?></h3>
                            </div>
                            <div class="mb-3 text-center">
                                <a href="<?php the_permalink(); ?> " class="btn btn-secondary" rel="bookmark"> Ver Noticia
                                </a>
                            </div>

                        </div>
                    </div>

                <?php endwhile; ?>
            <?php endif; ?>

        </div>
    </div>
</div>

<!--<?php cordero_numeric_posts_nav(); ?> -->


<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item disabled">
      <a class="page-link" href="https://fiestadelcordero.madryn.gob.ar/todas-las-noticias/" tabindex="-1" aria-disabled="true">Anterior</a>
    </li>
    <li class="page-item"><a class="page-link" href="https://fiestadelcordero.madryn.gob.ar/todas-las-noticias/">1</a></li>
    <li class="page-item"><a class="page-link" href="https://fiestadelcordero.madryn.gob.ar/todas-las-noticias/page/2/">2</a></li>
      <li class="page-item disabled">
      <a class="page-link" href="#">Siguiente</a>
    </li>
  </ul>
</nav>

</div>
<?php get_footer(); ?>
