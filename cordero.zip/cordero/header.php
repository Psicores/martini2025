<?php

/**
 * Theme Name: Header Pagina del tema de  Fiesta del Cordero
 * Theme URI:
 * Author: Municipalidad de Puerto Madryn
 * Author URI: 
 * Description: Cabecera con menu del sitio
 * Version: 1.0
 */
?>
<?php $template_option = cordero_get_global_options(); ?>

<!DOCTYPE html>
<html lang="<?php bloginfo('language') ?>">

<head>
    <meta charset="<?php bloginfo('charset') ?>">
    <meta name="description" content="<?php bloginfo('description') ?>">
    <link rel="manifest" href="<?php echo get_template_directory_uri(); ?>/manifest.json">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php bloginfo(); ?></title>
    <?php wp_head(); ?>
</head>

<body>
    <header>
        <div class="header-section-celular">
            <nav class="navbar navbar-expand-lg navbar-dark d-block d-sm-none manejo-burger" style="background-color: #283149;">
                <div class="container-fluid">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" style="margin-left: 42%;" data-bs-target="#navbarmenuCelu" aria-controls="navbarmenuCelu" aria-expanded="false" aria-label="Toggle navigation">
                        <img src="<?php bloginfo('template_directory') ?>/images/iconoBurger.svg" alt="" class="text-center zoom manejo-icono-burger"> </button>
                    <div class="collapse navbar-collapse" id="navbarmenuCelu">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container' => false,
                            'menu_class' => 'menu_nav nav navbar-nav ml-auto w-100 justify-content-center col',
                            'fallback_cb' => '__return_false',
                            'items_wrap' => '<ul id="%1$s" class="navbar-nav mx-auto mb-2 mb-md-0 %2$s">%3$s</ul>',
                            'depth' => 2,
                            'walker' => new cordero_nav_walker(),
                        ));
                        ?>
                    </div>
                </div>

            </nav>
        </div>



        <div class="header-section position-relative top-0 start-0" style="z-index:100;">
            <!-- <nav id="cordero-nav" class="navbar navbar-expand-lg navbar-light bg-light" -->
            <nav id="cordero-nav" class="navbar navbar-expand-sm navbar-light bg-light p-0 bg-transparent position-absolute mt-5 w-100" role="navigation">
                <div class="container-fluid">
                    <div class="collapse navbar-collapse" id="navbarmenu">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container' => false,
                            'menu_class' => 'menu_nav nav navbar-nav ml-auto w-100 justify-content-center col',
                            'fallback_cb' => '__return_false',
                            'items_wrap' => '<ul id="%1$s" class="navbar-nav mx-auto mb-2 mb-md-0 %2$s">%3$s</ul>',
                            'depth' => 2,
                            'walker' => new cordero_nav_walker(),
                        ));
                        ?>
                    </div>
                </div>
            </nav>
        </div>
    </header>
